from django.db import models

# Create your models here.
class Student(models.Model):
    
    name= models.CharField(max_length=200)
    student_id = models.IntegerField()
    semester = models.IntegerField(max_length=2)
    nationality = models.CharField(max_length=100)
    student_email_id = models.EmailField()
    
   


