from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth import authenticate,login
from .models import Student
from django.template import Context, Template
from app.forms import LoginForm
from django.views.generic.edit import FormView

# Create your views here.
def app(request):
    return HttpResponse("<h2><center>Welcome to DHFPH</center></h2>")
                        


class LoginFormView(FormView):
    
    template_name = "login.html"
    form_class = LoginForm
    success_url = "/checker/"

    def form_valid(self,form):
       # form = LoginForm(request.POST )
     form.clean()
     username = form .cleaned_data.get('Username')
     password = form.cleaned_data.get('Password')
     if password == "student":
      return super().form_valid(form)#form clean is called automatically when a valid form is added and returns a url
     else :
        return HttpResponseRedirect('login')    
                        
    
                                 


def checker(request):
    
    print(request.POST.get("Username"))
    if request.method == 'POST' :
       number=request.POST.get("Username")
       
       main = Student.objects.get(name=number)
        
       context = {
                    'name':  number, 
                    'Student_id': main.student_id,
                    'Sem': main.semester,
                    'Nationality': main.nationality,
                    'Email_id': main.student_email_id,
                }
       return render(request, 'dashboard.html', {
    'context':context}
   )
       
    else:
     return render(request, 'login.html')    
  
   
