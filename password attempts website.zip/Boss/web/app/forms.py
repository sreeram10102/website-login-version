from django import forms


class LoginForm(forms.Form):
    
    Username = forms.CharField(label="Username", max_length=100)
    Password = forms.CharField(label="Password", max_length=10)

    def clean(self):
        cleaned_data = super().clean()
        pass

        
       